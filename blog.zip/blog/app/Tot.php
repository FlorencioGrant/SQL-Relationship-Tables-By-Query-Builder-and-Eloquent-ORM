<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tot extends Model
{
    //
    protected $table = 'tos';



}
